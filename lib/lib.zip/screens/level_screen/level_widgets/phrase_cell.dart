import 'package:flutter/material.dart';

class PhraseCell extends StatelessWidget {
  final int index;
  final String? value;
  final int? number;
  final bool isRevealed;
  final bool isSelected;
  final bool isIncorrect;
  final bool isCorrect;
  final bool isCompleted;
  final VoidCallback onTap;
  final double cellSize;

  const PhraseCell({
    super.key,
    required this.index,
    required this.value,
    required this.number,
    required this.isRevealed,
    required this.isSelected,
    required this.isIncorrect,
    required this.isCorrect,
    required this.isCompleted,
    required this.onTap,
    required this.cellSize,
  });

  @override
  Widget build(BuildContext context) {
    final shouldShowNumber = number != null && !isCompleted;

    final cellHeight = cellSize * 1.28;
    final radius = (cellSize * 0.34).clamp(10.0, 15.0);
    final letterFontSize = (cellSize * 0.52).clamp(16.0, 22.0);
    final numberFontSize = (cellSize * 0.22).clamp(9.0, 11.0);
    final numberHeight = (cellSize * 0.34).clamp(10.0, 14.0);

    Color bgColor = Colors.white;
    Color borderColor = const Color(0xFFE2E8F0);
    Color textColor = const Color(0xFF0F172A);

    List<BoxShadow> shadows = [
      BoxShadow(
        blurRadius: cellSize * 0.18,
        offset: Offset(0, cellSize * 0.09),
        color: Colors.black.withOpacity(0.03),
      ),
    ];

    if (isIncorrect) {
      bgColor = const Color(0xFFFEE2E2);
      borderColor = const Color(0xFFFCA5A5);
      textColor = const Color(0xFFB91C1C);
    } else if (isSelected) {
      bgColor = const Color(0xFFEEF4FF);
      borderColor = const Color(0xFF5B8DEF);
      textColor = const Color(0xFF2563EB);
      shadows = [
        BoxShadow(
          blurRadius: cellSize * 0.3,
          offset: Offset(0, cellSize * 0.12),
          color: const Color(0xFF5B8DEF).withOpacity(0.16),
        ),
      ];
    } else if (isCompleted || isCorrect || isRevealed) {
      bgColor = const Color(0xFFF8FAFC);
      borderColor = const Color(0xFFD8E2EE);
      textColor = const Color(0xFF0F172A);
    }

    return GestureDetector(
      onTap: isRevealed || isCorrect ? null : onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: cellSize,
            height: cellHeight,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: borderColor,
                width: isSelected ? 1.8 : 1.1,
              ),
              boxShadow: shadows,
            ),
            child: Text(
              value?.toUpperCase() ?? '',
              style: TextStyle(
                fontSize: letterFontSize,
                fontWeight: FontWeight.w800,
                color: textColor,
              ),
            ),
          ),
          SizedBox(height: cellSize * 0.1),
          SizedBox(
            height: numberHeight,
            child: Text(
              shouldShowNumber ? number.toString() : '',
              style: TextStyle(
                fontSize: numberFontSize,
                color: Colors.grey.shade500,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}