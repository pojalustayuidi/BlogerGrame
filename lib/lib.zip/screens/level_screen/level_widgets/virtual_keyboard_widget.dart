import 'package:flutter/material.dart';

class VirtualKeyboardWidget extends StatefulWidget {
  final void Function(String, void Function() onLetterAccepted) onLetterPressed;
  final List<int> correctIndices;
  final List<int> revealed;
  final Map<String, int> letterMap;
  final List<String?> userInput;
  final String fullPhrase;

  const VirtualKeyboardWidget({
    super.key,
    required this.onLetterPressed,
    required this.correctIndices,
    required this.revealed,
    required this.letterMap,
    required this.userInput,
    required this.fullPhrase,
  });

  @override
  State<VirtualKeyboardWidget> createState() => _VirtualKeyboardWidgetState();
}

class _VirtualKeyboardWidgetState extends State<VirtualKeyboardWidget> {
  bool isLetterCompleted(String letter) {
    final number = widget.letterMap[letter];
    if (number == null) return false;

    final indices = widget.fullPhrase
        .toLowerCase()
        .split('')
        .asMap()
        .entries
        .where((e) => widget.letterMap[e.value] == number)
        .map((e) => e.key)
        .toList();

    return indices.every(
          (index) =>
      widget.revealed.contains(index) ||
          (widget.userInput[index]?.toLowerCase() ==
              widget.fullPhrase[index].toLowerCase()),
    );
  }

  bool isLetterUsed(String letter) {
    final number = widget.letterMap[letter];
    if (number == null) return false;

    final indices = widget.fullPhrase
        .toLowerCase()
        .split('')
        .asMap()
        .entries
        .where((e) => widget.letterMap[e.value] == number)
        .map((e) => e.key)
        .toList();

    return indices.any(
          (index) =>
      widget.revealed.contains(index) ||
          (widget.userInput[index]?.toLowerCase() ==
              widget.fullPhrase[index].toLowerCase()),
    );
  }

  Widget buildRow(List<String> rowLetters) {
    return Expanded(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final availableWidth = constraints.maxWidth;
          final buttonWidth = (availableWidth / rowLetters.length) - 4;
          final buttonHeight = buttonWidth * 1.34;

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: rowLetters.map((letter) {
              final lower = letter.toLowerCase();
              final completed = isLetterCompleted(lower);
              final used = isLetterUsed(lower);

              Color bgColor = Colors.white;
              Color fgColor = const Color(0xFF111827);
              Color borderColor = const Color(0xFFE5E7EB);

              if (completed) {
                bgColor = const Color(0xFFE5E7EB);
                fgColor = const Color(0xFF6B7280);
                borderColor = const Color(0xFFD1D5DB);
              } else if (used) {
                bgColor = const Color(0xFFEEF4FF);
                fgColor = const Color(0xFF5B8DEF);
                borderColor = const Color(0xFFBFDBFE);
              }

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: SizedBox(
                  width: buttonWidth,
                  height: buttonHeight,
                  child: ElevatedButton(
                    onPressed: completed
                        ? null
                        : () => widget.onLetterPressed(letter, () {}),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: bgColor,
                      foregroundColor: fgColor,
                      disabledBackgroundColor: bgColor,
                      disabledForegroundColor: fgColor,
                      padding: EdgeInsets.zero,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: borderColor),
                      ),
                    ),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        letter,
                        style: TextStyle(
                          fontSize: buttonWidth * 0.42,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final keyboardHeight = screenHeight * 0.29;

    const row1 = ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й'];
    const row2 = ['К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф'];
    const row3 = ['Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я'];

    return Container(
      height: keyboardHeight,
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(26),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 42,
            height: 5,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          const SizedBox(height: 12),
          buildRow(row1),
          const SizedBox(height: 8),
          buildRow(row2),
          const SizedBox(height: 8),
          buildRow(row3),
        ],
      ),
    );
  }
}