import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/game_provider.dart';
import '../../providers/player_provider.dart';
import '../../services/models/level.dart';
import '../menu_screen/menu_screen.dart';
import 'level_widgets/custom_level_appbar_widget.dart';
import 'level_widgets/level_compite_dialog.dart';
import 'level_widgets/phrase_board_card.dart';
import 'level_widgets/phrase_display_widget.dart';
import 'level_widgets/virtual_keyboard_widget.dart';

class LevelScreen extends ConsumerStatefulWidget {
  final Level currentLevel;
  final List<Level> allLevels;

  const LevelScreen({
    super.key,
    required this.currentLevel,
    required this.allLevels,
  });

  @override
  ConsumerState<LevelScreen> createState() => _LevelScreenState();
}

class _LevelScreenState extends ConsumerState<LevelScreen> {
  bool _isWinDialogShown = false;
  bool _isLossDialogShown = false;

  @override
  void initState() {
    super.initState();
    _isWinDialogShown = false;
    _isLossDialogShown = false;
  }

  @override
  void didUpdateWidget(covariant LevelScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.currentLevel.id != widget.currentLevel.id) {
      _isWinDialogShown = false;
      _isLossDialogShown = false;
    }
  }

  String formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<GameState>(
      gameProvider(widget.currentLevel),
          (previous, next) {
        if (!mounted) return;

        final player = ref.read(playerProvider).valueOrNull;

        if (previous?.isCompleted != true &&
            next.isCompleted &&
            !_isWinDialogShown) {
          _isWinDialogShown = true;

          final duration = DateTime.now().difference(next.startTime);
          final formattedTime = formatDuration(duration);

          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;

            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => LevelCompletedDialog(
                levelNumber: next.level.id,
                currentLevel: next.level,
                allLevels: widget.allLevels,
                formattedTime: formattedTime,
                rewards: next.level.reward,
                coinsAdded: next.level.reward,
                newcoins: (player?.coins ?? 0) + next.level.reward,
              ),
            ).then((_) {
              _isWinDialogShown = false;
            });
          });
        }

        if (previous?.isLost != true && next.isLost && !_isLossDialogShown) {
          _isLossDialogShown = true;

          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;

            _showLossDialog().then((_) {
              _isLossDialogShown = false;
            });
          });
        }
      },
    );

    final game = ref.watch(gameProvider(widget.currentLevel));

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFFF6F8FC),
        appBar: CustomLevelAppBar(
          levelId: game.level.id,
          errorCount: game.errorCount,
          allLevels: widget.allLevels,
          currentLevel: game.level,
        ),
        body: Stack(
          children: [
            Positioned(
              top: -90,
              left: -24,
              right: -24,
              child: Container(
                height: 190,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF5B8DEF), Color(0xFF6FC3FF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(36),
                    bottomRight: Radius.circular(36),
                  ),
                ),
              ),
            ),
            SafeArea(
              top: false,
              child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
                      child: PhraseBoardCard(
                        level: game.level,
                        userInput: game.userInput,
                        selectedIndex: game.selectedIndex,
                        incorrectIndices: game.incorrectIndices,
                        correctIndices: game.correctIndices,
                        completedNumbers: game.completedNumbers,
                        onSelect: (index) {
                          ref
                              .read(gameProvider(widget.currentLevel).notifier)
                              .selectCell(index);
                        },
                      ),
                    ),
                  ),
                  VirtualKeyboardWidget(
                    onLetterPressed: (letter, onAccepted) {
                      ref
                          .read(gameProvider(widget.currentLevel).notifier)
                          .pressLetter(letter);
                    },
                    correctIndices: game.correctIndices,
                    revealed: game.revealed,
                    letterMap: game.level.letterMap,
                    userInput: game.userInput,
                    fullPhrase: game.level.quote,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _goHome() async {
    ref.invalidate(gameProvider(widget.currentLevel));

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => MenuScreen(
          levels: widget.allLevels,
          currentLevel: widget.currentLevel,
        ),
      ),
    );
  }

  Future<void> _retryLevel() async {
    ref.read(gameProvider(widget.currentLevel).notifier).resetLevel();

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _showLossDialog() async {
    final playerLives = ref.read(playerProvider).valueOrNull?.lives ?? 0;

    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: const Center(
            child: Text(
              'Вы проиграли',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              const Icon(
                Icons.sentiment_very_dissatisfied_rounded,
                size: 50,
                color: Colors.orange,
              ),
              const SizedBox(height: 16),
              Text(
                playerLives <= 0
                    ? 'У вас закончились жизни.'
                    : 'Вы сделали 5 ошибок.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: const Icon(Icons.home_rounded, size: 32),
                    onPressed: _goHome,
                  ),
                  ElevatedButton(
                    onPressed: _retryLevel,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF5B8DEF),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text('Переиграть'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}